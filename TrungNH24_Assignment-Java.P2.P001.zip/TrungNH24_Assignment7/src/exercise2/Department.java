package exercise2;

import java.util.List;

public class Department {

	private String departmentName;
	private List<Employee> listOfEmployee;
	
	public List<Employee> getListOfEmployee() {
		return listOfEmployee;
	}
	public void setListOfEmployee(List<Employee> listOfEmployee) {
		this.listOfEmployee = listOfEmployee;
	}
	public Department(String departmentName, List<Employee> listOfEmployee) {
		super();
		this.departmentName = departmentName;
		this.listOfEmployee = listOfEmployee;
	}
	public Department() {
		
	}
	public Department(String departmentName) {
		super();
		this.departmentName = departmentName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	public void display() {
		System.out.print("\t" + departmentName);
	}
	@Override
	public String toString() {
		
		return departmentName;
	}
	
}
