package exercise2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ManagerEmployeeTest {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Validation validation = new Validation();
		ManageDepartmentFunction manage = new ManageDepartmentFunction();
		List<Employee> listSalariedEmployee = new ArrayList<Employee>();
		Department department = new Department();
		List<Department> listDepartment = new ArrayList<Department>();
		while (true) {
			System.out.println("====== DepartmentManage ======");
			System.out.println("1. Input information of employee");
			System.out.println("2. Display information of employees");
			System.out.println("3. Find Classify employees");
			System.out.println("4. Search employee");
			System.out.println("5. Report employee");
			System.out.println("Enter your choice: ");
			int choice = validation.checkInputInt();
			switch (choice) {
			case 1: {
				manage.inputInfoOfEmployee(listSalariedEmployee, listDepartment);
				break;
			}
			case 2: {
				manage.displayEmployee(listSalariedEmployee, listDepartment);
				break;
			}
			case 3: {
				manage.classifyEmployee(listSalariedEmployee, listDepartment);
				break;
			}
			case 4: {
				manage.search(listSalariedEmployee, listDepartment);
				break;
			}
			case 5: {
				manage.reportDepartment(listDepartment);
				break;
			}
			case 6: {
				System.out.println("======= End task =========");
				return;
			}
			default: {
				System.out.println("Please input from 1 to 6!!!!");
				break;

			}

			}
			System.out.println();
		}
	}
}
