package exercise2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Validation {
	private static final String EMAIL = "\\w+@\\w+[.]\\w+";
	private static final String PHONE_NUMBER = "\\d{10}";
	static Scanner scanner = new Scanner(System.in);

	/*
	 * check format input Email
	 */
	public static String checkInputEmail() {
		while (true) {
			String result = scanner.nextLine().trim();
			if (result.length() != 0 && result.matches(EMAIL)) {
				return result;
			} else {
				System.err.println("Email is not correct, Re-input");
			}
		}
	}

	/*
	 * check format input date(dd/MM/yyyy)
	 */
	public String inputDate() {
		while (true) {
			try {
				String result = scanner.nextLine().trim();
				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				Date date = format.parse(result);
				if (result.equalsIgnoreCase(format.format(date))) {
					return result;
				} else {
					System.err.println("Date must is correct format(dd/MM/yyyy)");
				}
			} catch (NumberFormatException ex) {
				System.err.println("Date must is correct format(dd/MM/yyyy)");
			} catch (ParseException ex) {
				System.err.println("Date must is correct format(dd/MM/yyyy)");
			}
		}
	}

	/*
	 * check format input phone number
	 */
	public static String checkInputPhone() {
		while (true) {
			String result = scanner.nextLine().trim();
			if (result.length() != 0 && result.matches(PHONE_NUMBER)) {
				return result;
			} else {
				System.err.println("Phone number is not correct, Re-input: ");
			}
		}
	}

	/*
	 * check input correct integer number
	 */
	public static int checkInputInt() {
		while (true) {
			try {
				int result = Integer.parseInt(scanner.nextLine());
				return result;
			} catch (NumberFormatException ex) {
				System.err.println("You must input Integer");
			}
		}
	}
}
