package exercise2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ManageDepartmentFunction {
	static Scanner scanner = new Scanner(System.in);
	static Validation validation = new Validation();

	/*
	 * input information of employee
	 */
	public void inputInfoOfEmployee(List<Employee> listSalariedEmployee, List<Department> department) {
		while (true) {
			System.out.println("1. Input information of Salary Employee");
			System.out.println("2. Input information of Hourly Employee");
			System.out.println("3. Exit");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				System.out.print("Enter ssn: ");
				String ssn = scanner.next();
				System.out.print("Enter first name: ");
				String firstName = scanner.next();
				System.out.print("Enter lastName: ");
				String lastName = scanner.next();
				System.out.print("Enter birthday: ");
				String birthday = validation.inputDate();
				System.out.print("Enter phone: ");
				String phone = validation.checkInputPhone();
				System.out.print("Enter email: ");
				String email = validation.checkInputEmail();
				System.out.print("Enter commissionRate: ");
				Double commissionRate = scanner.nextDouble();
				System.out.print("Enter grossSales :");
				Double grossSale = scanner.nextDouble();
				System.out.println("Enter basic salary: ");
				Double basicSalary = scanner.nextDouble();
				System.out
						.println("Enter department name (1 - Human resouces, 2- Marketing, 3- Management, 4-security)");
				int departmentID = scanner.nextInt();
				String departmentName = ParseDepartmentName(departmentID);
				Employee employee = new SalariedEmployee(ssn, firstName, lastName, birthday, phone, email,
						commissionRate, grossSale, basicSalary);
				listSalariedEmployee.add(employee);
				department.add(new Department(departmentName, listSalariedEmployee));
				break;
			}
			case 2: {
				System.out.print("Enter ssn: ");
				String ssn = scanner.next();
				System.out.print("Enter first name: ");
				String firstName = scanner.next();
				System.out.print("Enter lastName: ");
				String lastName = scanner.next();
				System.out.print("Enter birthday: ");
				String birthday = validation.inputDate();
				System.out.print("Enter phone: ");
				String phone = validation.checkInputPhone();
				System.out.print("Enter email: ");
				String email = validation.checkInputEmail();
				System.out.println("Enter wage: ");
				Double wage = scanner.nextDouble();
				System.out.println("Enter working hour: ");
				Double workinghour = scanner.nextDouble();
				System.out
						.println("Enter department name (1 - Human resouces, 2- Marketing, 3- Management, 4-security)");
				int departmentID = scanner.nextInt();
				String departmentName = ParseDepartmentName(departmentID);
				Employee employee = new HourlyEmployee(ssn, firstName, lastName, birthday, phone, email, wage,
						workinghour);
				listSalariedEmployee.add(employee);
				department.add(new Department(departmentName, listSalariedEmployee));
				break;
			}
			case 3: {
				return;
			}
			}
		}
	}

	/*
	 * display all information of list employee
	 */
	public void displayEmployee(List<Employee> listSalariedEmployee, List<Department> department) {
		for (int i = 0; i < department.size(); i++) {
			department.get(i).display();
			System.out.println("\t" + listSalariedEmployee.get(i).toString());
		}
	}

	/*
	 * display class(SalariedEmployee, HourlyEmployee) and department of each
	 * employee in list
	 */
	public void classifyEmployee(List<Employee> listSalariedEmployee, List<Department> department) {
		for (int i = 0; i < listSalariedEmployee.size(); i++) {
			if (listSalariedEmployee.get(i) instanceof SalariedEmployee) {
				System.out.print("\t" + listSalariedEmployee.get(i).getFirstName() + " "
						+ listSalariedEmployee.get(i).getLastName() + "\t" + "SalariedEmployee");
				department.get(i).display();
			} else {
				System.out.print("\t" + listSalariedEmployee.get(i).getFirstName() + " "
						+ listSalariedEmployee.get(i).getLastName() + "\t" + "HourlyEmployee" + "\t");
				department.get(i).display();
			}
			System.out.println();
		}
	}

	/*
	 * search employee by department and name of emloyee enter name of department,
	 * then, if have department search in list, console display list name of
	 * department, else console display notification
	 * 
	 */

	public void search(List<Employee> listSalariedEmployee, List<Department> department) {
		if (listSalariedEmployee.isEmpty() || department.isEmpty()) {
			System.err.println("List is empty");
		} else {
			System.out.println("Enter department name: ");
			String departmentNameSearch = scanner.next();
			for (int i = 0; i < department.size(); i++) {
				if (department.get(i).getDepartmentName().equalsIgnoreCase(departmentNameSearch)) {
					department.get(i).display();
					System.out.println("\t" + listSalariedEmployee.get(i).getFirstName() + " "
							+ listSalariedEmployee.get(i).getLastName());
				} else {
					System.out.println("No Data");
					break;
				}
			}

			System.out.println("Do you want to search more information(Y/N): ");
			String choice = scanner.next();
			if (choice.equalsIgnoreCase("y")) {
				System.out.println("Enter last name of employee: ");
				String nameEml = scanner.next();
				for (int j = 0; j < listSalariedEmployee.size(); j++) {
					if ((listSalariedEmployee.get(j).getLastName().trim()).equals(nameEml.trim())) {
						System.out.println("\t" + listSalariedEmployee.get(j).toString());
					} else {
						System.out.println("No data match your search information!!!");
					}
				}
			} else if (choice.equalsIgnoreCase("N")) {
				System.out.println("--------------End task----------");
			} else {
				System.out.println("--------------End task----------");
			}
		}
	}

	/*
	 * display information of emloyees in each department(total employee of
	 * department and number of each department)
	 */
	public void reportDepartment(List<Department> department) {
		int countHumanResouces = 0;
		int countMarketing = 0;
		int countManagement = 0;
		int countSecurity = 0;
		for (int i = 0; i < department.size(); i++) {
			if (department.get(i).getDepartmentName().equalsIgnoreCase("HumanResouces")) {
				countHumanResouces++;
			}
			if (department.get(i).getDepartmentName().equalsIgnoreCase("Marketing")) {
				countMarketing++;
			}
			if (department.get(i).getDepartmentName().equalsIgnoreCase("Management")) {
				countManagement++;
			}
			if (department.get(i).getDepartmentName().equalsIgnoreCase("Security")) {
				countSecurity++;
			}
		}
		System.out.println("Report Deparment");
		System.out.println("Number employees of Department: " + department.size());
		System.out.println("Number employees of HumanResouces department: " + countHumanResouces);
		System.out.println("Number employees of Marketing department: " + countMarketing);
		System.out.println("Number employees of Management department: " + countManagement);
		System.out.println("Number employees of Security department: " + countSecurity);
	}

	/*
	 * return String for input department in inputInfoOfEmployee() function.
	 */
	public String ParseDepartmentName(int n) {
		if (n == 1) {
			return "HumanResouces";
		}
		if (n == 2) {
			return "Marketing";
		}
		if (n == 3) {
			return "Management";
		}
		if (n == 4) {
			return "Security";
		}
		return null;
	}
}
