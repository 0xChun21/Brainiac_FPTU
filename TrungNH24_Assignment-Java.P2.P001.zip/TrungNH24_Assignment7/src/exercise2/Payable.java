package exercise2;

public interface Payable {
	
	double getPaymentAmount();
	
}
