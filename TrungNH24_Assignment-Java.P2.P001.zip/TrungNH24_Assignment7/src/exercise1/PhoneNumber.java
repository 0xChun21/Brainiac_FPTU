package exercise1;

import java.util.Scanner;

public class PhoneNumber {
	private static final String PHONE_NUMBER = "\\d{10}";

	public int inputNumber(Scanner scanner) {
		int phoneNumber = 0;
		String stringPhoneNumber = scanner.next();
		try {
			phoneNumber = Integer.parseInt(stringPhoneNumber);
			boolean check;
			check = stringPhoneNumber.matches(PHONE_NUMBER);
			if (check) {
				System.out.println("Phone number :" + phoneNumber);
			} else {
				System.out.println("Phone number must be 10 digits!");
				this.input();
			}
		} catch (Exception e) {
			System.out.println("Phone number must is number");
			this.input();
		}
		return phoneNumber;

	}

	public void input() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Phone number: ");
		int number = inputNumber(scanner);
	}

}
