package exercise1;

import java.util.Scanner;

public class Email {
	private static final String EMAIL = "\\w+@\\w+[.]\\w+";

	public void input() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Email:");
		while (true) {
			String email = scanner.next();
			boolean check = email.matches(EMAIL);
			if (check) {
				System.out.println("Email is correct format");
				break;
			} else {
				System.out.println("Email must is correct format");
			}
			
		}

	}
}
