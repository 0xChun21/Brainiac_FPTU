package exercise1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		while (true) {
			System.out.println("=================Start Program===============");
			System.out.println("1. Phone Number");
			System.out.println("2. Email");
			System.out.println("3. Date");
			System.out.println("4. Exit");
			System.out.println("Please choice one option:");
			Scanner scanner = new Scanner(System.in);
			String option = scanner.next();

			Integer ioption = 0;
			try {
				ioption = Integer.parseInt(option);
			} catch (Exception e) {
				System.out.println("Input Your choice");
			}

			switch (ioption) {
			case 1: {
				System.out.println("------------ Phone Number ---------------");
				PhoneNumber phoneNumber = new PhoneNumber();
				phoneNumber.input();
				break;
			}
			case 2: {
				System.out.println("------------ Email ---------------");
				Email email = new Email();
				email.input();
			}
				break;
			case 3: {
				System.out.println("------------ Date ---------------");
				GetDate getDate = new GetDate();
				getDate.input();
			}
				break;
			case 4: {
				scanner.close();
				System.out.println("End task");
			}

			default:
				System.out.println("Please input from 1 to 4!!!!");
				break;
			}
		}

	}

}
