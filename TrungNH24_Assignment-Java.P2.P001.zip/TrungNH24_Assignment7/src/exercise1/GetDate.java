package exercise1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class GetDate {
	public String input() {
		Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
            	System.out.print("Date:");
                String result = scanner.nextLine().trim();
                SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                Date date = format.parse(result);
                if (result.equalsIgnoreCase(format.format(date))) {
                    return result;
                } else {
                    System.out.println("Date must is correct format(dd/MM/yyyy)");
                }
            } catch (NumberFormatException ex) {
                System.err.println("Date must is correct format(dd/MM/yyyy)");
            } catch (ParseException ex) {
                System.err.println("Date must is correct format(dd/MM/yyyy)");
            }
        }
	}
}
