package exercise2;

public class EastAsiaCountries extends Country implements Comparable<EastAsiaCountries> {
	private String countryTerrain;
	public EastAsiaCountries() {
		super();
	}

	public EastAsiaCountries(String countryCode, String countryName, float totalArea, String countryTerrain) {
		super(countryCode, countryName, totalArea);
		this.countryTerrain = countryTerrain;
	}

	public String getCountryTerrain() {
		return countryTerrain;
	}

	public void setCountryTerrain(String countryTerrain) {
		this.countryTerrain = countryTerrain;
	}
	@Override
	public String display() {
		
		return super.display() + "\t" + countryTerrain;
	}

	@Override
	public int compareTo(EastAsiaCountries other) {
		return this.getCountryName().compareTo(other.getCountryName());
	}
	

}
