package exercise2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


public class ManageEastAsiaCountries {
	public static void main(String[]  args){
		
		int n;
		ManageEastAsiaCountries manager = new ManageEastAsiaCountries();
		ArrayList<EastAsiaCountries> eastAsiaCountries = new ArrayList<EastAsiaCountries>();
		Scanner scanner = new Scanner(System.in);
		
		while (true) {
			System.out.println("1. Input the information of 11 countries in East Asia");
			System.out.println("2. Display the information of country you've just input");
			System.out.println("3. Search the information of country by user-entered name");
			System.out.println("4. Display the information of countries sorted name in ascending order");
			System.out.println("5. Exit");
			n = scanner.nextInt();
			switch (n) {
			case 1:{
				manager.addCountryInformation(eastAsiaCountries);
				break;
			}
			case 2:{
				System.out.println("ID\tName\t\tTotal\tArea");
				manager.getRecentlyEnteredInformation(eastAsiaCountries);
				break;
			}
			case 3:{
				manager.searchInformationByName(eastAsiaCountries);
				break;
			}
			case 4:{
				manager.sortInformationByAscendingOrder(eastAsiaCountries);
				manager.getRecentlyEnteredInformation(eastAsiaCountries);
				break;
			}
			case 5:{
				return;
			}
				
			default:
				break;
			}
		}
	}
	
	public void addCountryInformation(ArrayList<EastAsiaCountries> eastAsiaCountries){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter code of country: ");
		String code = sc.nextLine();
		System.out.println("Enter name of country: ");
		String name = sc.nextLine();
		System.out.println("Enter total Area: ");
		float area = sc.nextFloat();
		System.out.println("Enter terrain of country: ");
		String terrain = sc.next();
		eastAsiaCountries.add(new EastAsiaCountries(code, name, area, terrain));
		
	}
	public void getRecentlyEnteredInformation(ArrayList<EastAsiaCountries> eastAsiaCountries){

		for (int i = 0; i < eastAsiaCountries.size(); i++) {
			
			System.out.println(eastAsiaCountries.get(i).display());
		}
	}
	
	public void searchInformationByName(ArrayList<EastAsiaCountries> eastAsiaCountries){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the name you want to search for: ");
		String name = scanner.next();
			for (int i = 0; i < eastAsiaCountries.size(); i++) {
				if (eastAsiaCountries.get(i).countryName.equals(name)) {
					System.out.println(eastAsiaCountries.get(i).display());
				}else {
					System.out.println("No country information match input name");
				}
			}
		
	}
	public void sortInformationByAscendingOrder(ArrayList<EastAsiaCountries> eastAsiaCountries){
		Collections.sort(eastAsiaCountries);
	}
}
