package Exercise1;

import java.util.Scanner;

public class CalculatorProgram {
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		ProgramFunction program = new ProgramFunction();
		while (true) {
			System.out.println("========Calculator Program========");
			System.out.println("1. Normal Calculator");
			System.out.println("2. BMI calculator");
			System.out.println("3. Exit");
			System.out.print("Please choice one option: ");
			int choice = scanner.nextInt();
			
			switch (choice) {
			case 1:{
				program.calculate();
				break;
			}
			case 2:{
				System.out.println("----- BMI Calculator ----");
				System.out.println("Enter Weight(kg) : ");
				double weight = program.checkInteger();
				System.out.println("Enter Height(cm) : ");
				double height = program.checkInteger();
				program.calculateBMI(weight, height);
				break;
			}
			case 3:{
				return;
			}
			
			}
			
		}
	}
}
