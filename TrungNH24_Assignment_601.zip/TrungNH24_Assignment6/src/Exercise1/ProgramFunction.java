package Exercise1;

import java.util.Scanner;

public class ProgramFunction {
	static Scanner scanner = new Scanner(System.in);

	public void calculate() {
		double num1, num2;
		String operator;
		double memory = 0;
		System.out.println("---- Normal Calculator ----");
		System.out.print("Enter number: ");
		num1 = scanner.nextDouble();
		System.out.print("Enter Operator: ");
		operator =scanner.next();
		System.out.println("Enter number: ");
		num2 = scanner.nextDouble();
		switch (operator.charAt(0)) {
		case '+': {
			memory = num1 + num2;
			System.out.println("memory: " + memory);
			break;
		}
		case '-': {
			memory = num1 - num2;
			System.out.println("memory: " + memory);
			break;
		}
		case '*': {
			memory = num1 * num2;
			System.out.println("memory: " + memory);
			break;
		}
		case '/': {
			if (num2 == 0) {
				System.out.println("number two can't be zero");
			} else {
				memory = num1 / num2;
				System.out.println("memory: " + memory);
			}
			break;
		}
		case '^': {
			memory = Math.pow(num1, num2);
			System.out.println("memory: " + memory);
			break;
		}
		}

		while (true){
			System.out.println("enter operator: ");
			operator = scanner.next();
			double temp =0;
			switch (operator.charAt(0)) {
			case '+': {
				System.out.println("enter number: ");
				 temp = scanner.nextDouble();
				memory = memory + temp;
				System.out.println("memory: " + memory);
				break;
			}
			case '-': {
				System.out.println("enter number: ");
				 temp = scanner.nextDouble();
				memory = memory - temp;
				System.out.println("memory: " + memory);
				break;
			}
			case '*': {
				System.out.println("enter number: ");
				 temp = scanner.nextDouble();
				memory = memory * temp;
				System.out.println("memory: " + memory);
				break;
			}
			case '/': {
				System.out.println("enter number: ");
				 temp = scanner.nextDouble();
				if (temp == 0) {
					System.out.println("num2 can't be zero");
				} else {
					memory = memory / temp;
					System.out.println("memory: " + memory);
				}
				break;
			}
			case '^': {
				System.out.println("enter number: ");
				 temp = scanner.nextDouble();
				memory = Math.pow(memory, temp);
				System.out.println("memory: " + memory);
				break;
			}
			case'=':{
				System.out.println("Result: " + memory);
				return;
			}
			}
		} 

	}

	public void calculateBMI(double weight, double height) {
		double BMINumber = weight / (Math.pow((height * 0.01), 2));
		if (BMINumber < 19) {
			System.out.println("BMI Number: " + BMINumber);
			System.out.println("Under Weight");
		}
		if (BMINumber >= 19 && BMINumber < 25) {
			System.out.println("BMI Number: " + BMINumber);
			System.out.println("Normal");
		}
		if (BMINumber >= 25 && BMINumber < 30) {
			System.out.println("BMI Number: " + BMINumber);
			System.out.println("Over Weight");
		}
		if (BMINumber >= 30 && BMINumber < 40) {
			System.out.println("BMI Number: " + BMINumber);
			System.out.println("Obese");
		}
		if (BMINumber >= 40) {
			System.out.println("BMI Number: " + BMINumber);
			System.out.println("Extremely Obese");
		}
	}
	public int checkInteger() {
		while (true) {
			try {
				int number = Integer.parseInt(scanner.nextLine());
				return number;
			} catch (Exception e) {
				System.out.println("BMI is digit");
			}
		}
	}

}
