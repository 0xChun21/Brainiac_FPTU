package Exercise1;

import java.util.Scanner;

public class TestShape {
	public static void main(String[] args) {
		double width, length, radius, sideA, sideB, sideC;
		Scanner scanner = new Scanner(System.in);
		System.out.println("=====Calculator Shape Progaramer=====");
		System.out.println("Please input side width of Rectangle: ");
		width = scanner.nextDouble();
		System.out.println("Please input side length of Rectangle: ");
		length = scanner.nextDouble();;
		System.out.println("Please input radius of Circle: ");
		radius = scanner.nextDouble();
		System.out.println("Please input side A of Triangle: ");
		sideA = scanner.nextDouble();
		System.out.println("Please input side B of Triangle: ");
		sideB = scanner.nextDouble();
		System.out.println("Please input side C of Triangle: ");
		sideC = scanner.nextDouble();
		
		Rectangle rectangle = new Rectangle(width, length);
		Circle circle = new Circle(radius);
		Triangle triangle = new Triangle(sideA, sideB, sideC);
		
		rectangle.printResult();
		circle.printResult();
		triangle.printResult();
		
		
	}

}
