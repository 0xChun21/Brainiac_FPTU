package Exercise2;

public class Person {
	public Person() {
		
	}
	public int calcTotal(int [] bills) {
		int totalBills = 0;
		for (int i = 0; i < bills.length; i++) {
			totalBills += bills[i];
		}
		return totalBills;
	}

}
