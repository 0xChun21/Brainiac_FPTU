package Exercise2;

public class Wallet extends Person{

	private int walletValue;

	public Wallet(int walletValue) {
		super();
		this.walletValue = walletValue;
	}

	public int getWalletValue() {
		return walletValue;
	}

	public void setWalletValue(int walletValue) {
		this.walletValue = walletValue;
	}
	
	public boolean payMoneỵ̣̣(int total) {
		if (walletValue>=total) {
			return true;
		}else {
			return false;
		}
		
	}

}