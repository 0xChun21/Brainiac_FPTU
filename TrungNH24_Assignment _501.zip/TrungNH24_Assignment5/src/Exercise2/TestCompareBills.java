package Exercise2;

import java.util.Scanner;

public class TestCompareBills {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int billNumbers;
		int walletValue;
		Person person = new Person();
		System.out.println("===== Shopping program ===========");
		System.out.print("input number of bill:");
		billNumbers = scanner.nextInt();
		int [] bills = new int[billNumbers];
		
		for (int i = 0; i < billNumbers; i++) {
			System.out.print("input value of bill "+(i+1)+":");
			bills[i]=scanner.nextInt();
		}
		System.out.print("input value of wallet:");
		walletValue= scanner.nextInt();
		Wallet wallet = new Wallet(walletValue);
		if (wallet.payMoneỵ̣̣(person.calcTotal(bills))==true) {
			System.out.println("this is total of bill:" + person.calcTotal(bills));
			System.out.println("You can buy it.");
		} else {
			System.out.println("this is total of bill:" + person.calcTotal(bills));
			System.out.println("You can't buy it.");
		}
		
		
		
		
		
		
	}
	

}
