package Excercise2;

public class ArrayContains {
	public static void main(String[] args) {
		
		String [] stringArray= {"FTP","Fresher", "Acedemy", "2018"};
		
		for (int i = 0; i < stringArray.length; i++) {
			if (stringArray[i].equals("Fresher")) {
				System.out.print("Check 'Fresher' in Array: Contained!");
			}
		}
	}
}
