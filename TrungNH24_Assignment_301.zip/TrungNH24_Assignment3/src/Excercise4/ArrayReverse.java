package Excercise4;

import java.util.Iterator;
public class ArrayReverse {
	
	public static void main(String[] args) {
		  int[] myIntArray = { 43, 32, 53, 23, 12, 34, 3, 12, 43, 32 };
		  int temp=0;
		  for (int i = 0; i < myIntArray.length / 2; i++) {
			  	temp = myIntArray[i];
			  	myIntArray[i] = myIntArray[myIntArray.length-i-1];
			  	myIntArray[myIntArray.length-i-1] = temp;
					
			}

		  for (int i = 0; i < myIntArray.length; i++) {
			System.out.print(myIntArray[i]+" ");
		}
		  
	}

}
