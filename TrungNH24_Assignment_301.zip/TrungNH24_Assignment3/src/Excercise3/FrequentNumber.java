package Excercise3;

public class FrequentNumber {
	public static void main(String[] args) {
		 int[] intArray = new int[5];
		 intArray[0]=5;
		 intArray[1]=7;
		 intArray[2]=5;
		 intArray[3]=8;
		 intArray[4]=3;
		 
		 int count =0;
		 
		 for (int i = 0; i < intArray.length; i++) {
			if (intArray[i] == 5) {
				count++;
			}
		}
		 System.out.print("Amount of frequence:"+count);
		 
		 
		 
		 
	}

}
