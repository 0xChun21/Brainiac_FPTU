package Excercise1;

public class SumAverageRunningInt {
	public static void main(String[] args) {
		int sum=0;
		double average=0.0d;
		for (int i = 1; i <=100; i++) {
			sum += i;
		}
		
		System.out.print("Average of all 100 first numbers:"+(sum/100));
	}

}
