package exercise2;

public class EmployeeTest {
	public static void main(String  [] args) {
		Employee e1= new Employee("Trung", "Hoang", 12);
		Employee e2 = new Employee("Quan", "Chun", 0);
		
		System.out.println(e1.getSalary());
		System.out.println(e2.getSalary());
		e1.setSalary(e1.getSalary()*2);
		System.out.println(e1.getSalary());
		e1.setSalary(e2.getSalary()*2);
		System.out.println(e2.getSalary());
		
		
		
	}

}
