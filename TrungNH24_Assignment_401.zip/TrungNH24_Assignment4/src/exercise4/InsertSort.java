package exercise4;

public class InsertSort extends NumberList implements Sort {

	public InsertSort(int n) {
		super(n);
	}

	public static void main(String[] args) {
		InsertSort i = new InsertSort(0);
		i.input();
		System.out.println("Array before sort: ");
		i.print();
		i.sort();
		System.out.println("Array after sort: ");
		i.print();

	}

	@Override
	public void sort() {
		for (int i = 0; i < arr.length; i++) {
			int value = arr[i];
			int j = i - 1;
			while (j >= 0 && arr[j] > value) {
				arr[j + 1] = arr[j];
				j = j - 1;
			}
			arr[j + 1] = value;
		}
		
	}

}
