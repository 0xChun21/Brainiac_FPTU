package exercise4;

public class SelectionSort extends NumberList implements Sort{

	public SelectionSort(int n) {
		super(n);
		
	}

	public static void main(String[] args) {
		SelectionSort s = new SelectionSort(0);
		s.input();
		System.out.println("Array before sort: ");
		s.print();
		s.sort();
		System.out.println("Array after sort: ");
		s.print();

	}

	@Override
	public void sort() {
        for (int i = 0; i < arr.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                int temp = arr[minIndex];
                arr[minIndex] = arr[i];
                arr[i] = temp;
            }
             
        }
        System.out.println();
		
	}

}
