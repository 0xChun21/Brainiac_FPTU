package exercise4;

public interface Sort {
	public void sort();

}
