package exercise4;
import java.util.Scanner;

public class NumberList {
	int n;
	int [] arr;
	Scanner sc = new Scanner(System.in);
	public void input() {
		System.out.println("Size of array: ");
		n = sc.nextInt();
		arr = new int[n];
		for (int i = 0; i < n; i++) {
			System.out.println("element: ");
			arr[i] = sc.nextInt();
		}
	}
	public void print() {
		for (int i = 0; i < n; i++) {
			System.out.print(arr[i] + "\t");
		}
	}
	
	public NumberList(int n) {
		arr = new int[n];

	}
}
