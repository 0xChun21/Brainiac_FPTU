package exercise3;

public class MyOwnAutoShop {
	
	public static void main(String [] args) {
		Sedan sedan1 = new Sedan(250, 150, "BabyBlue", 30);
		Ford ford1 = new Ford(200,200 , "Red", 2021, 50);
		Ford ford2 = new Ford(300,450 , "Yellow", 2020, 80);
		Car car1= new Truck(200, 300, "black", 200);
		
		System.out.println(sedan1.getSalePrice());
		System.out.println(ford1.getSalePrice());
		System.out.println(ford2.getSalePrice());
		System.out.println(car1.getSalePrice());
		
	}

}
