package exercise1;

public class Book {
	private String bookName;
	private int bookID;
	private String bookAuthor;
	private String bookPublisher;
	
	public Book() {
		
	}

	public Book(String bookName, int bookID, String bookAuthor, String bookPublisher) {
		super();
		this.bookName = bookName;
		this.bookID = bookID;
		this.bookAuthor = bookAuthor;
		this.bookPublisher = bookPublisher;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getBookID() {
		return bookID;
	}

	public void setBookID(int bookID) {
		this.bookID = bookID;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getBookPublisher() {
		return bookPublisher;
	}

	public void setBookPublisher(String bookPublisher) {
		this.bookPublisher = bookPublisher;
	}
	
	public String getBookInfo() {
		return bookName+"	"+bookID+"	"+bookAuthor+"	"+bookPublisher;
	}

	
	
	

}
