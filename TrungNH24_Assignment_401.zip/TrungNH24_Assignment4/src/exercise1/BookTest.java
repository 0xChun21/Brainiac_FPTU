package exercise1;
import java.util.Arrays;

public class BookTest {
	
	public static void main(String [] args) {

		Book [] bookList =new Book[30];
		bookList[0] = new Book("a", 1, "hoangTrung", "quanChun");
		bookList[1] = new Book("b", 2, "hoangTrung", "quanChun");
		bookList[2] = new Book("c", 3, "hoangTrung", "quanChun");
		bookList[3] = new Book("d", 4, "hoangTrung", "quanChun");
		bookList[4] = new Book("e",5, "hoangTrung", "quanChun");
		bookList[5] = new Book("f", 6, "hoangTrung", "quanChun");
		bookList[6] = new Book("g", 7, "hoangTrung", "quanChun");
		bookList[7] = new Book("h", 8, "hoangTrung", "quanChun");
		bookList[8] = new Book("j", 9, "hoangTrung", "quanChun");
		bookList[9] = new Book("k", 10, "hoangTrung", "quanChun");
		bookList[10] = new Book("l", 11, "hoangTrung", "quanChun");
		bookList[11] = new Book("m", 12, "hoangTrung", "quanChun");
		bookList[12] = new Book("n", 13, "hoangTrung", "quanChun");
		bookList[13] = new Book("q", 14, "hoangTrung", "quanChun");
		bookList[14] = new Book("w", 15, "hoangTrung", "quanChun");
		bookList[15] = new Book("r", 16, "hoangTrung", "quanChun");
		bookList[16] = new Book("t", 17, "hoangTrung", "quanChun");
		bookList[17] = new Book("y", 18, "hoangTrung", "quanChun");
		bookList[18] = new Book("u", 19, "hoangTrung", "quanChun");
		bookList[19] = new Book("i", 20, "hoangTrung", "quanChun");
		bookList[20] = new Book("o", 22, "hoangTrung", "quanChun");
		bookList[21] = new Book("p", 23, "hoangTrung", "quanChun");
		bookList[22] = new Book("s", 24, "hoangTrung", "quanChun");
		bookList[23] = new Book("f", 25, "hoangTrung", "quanChun");
		bookList[24] = new Book("g", 26, "hoangTrung", "quanChun");
		bookList[25] = new Book("z", 27, "hoangTrung", "quanChun");
		bookList[26] = new Book("x", 28, "hoangTrung", "quanChun");
		bookList[27] = new Book("v", 29, "hoangTrung", "quanChun");
		bookList[28] = new Book("q", 30, "hoangTrung", "quanChun");
		bookList[29] = new Book("q", 21, "hoangTrung", "quanChun");
		
		for(int i=0;i<bookList.length;i++) {
			System.out.println(bookList[i].getBookInfo());
		}

		
	}

}
